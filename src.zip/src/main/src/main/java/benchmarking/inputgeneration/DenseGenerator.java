package main.java.benchmarking.inputgeneration;

import main.java.graph.Edge;
import main.java.graph.Graph;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class DenseGenerator implements GraphGenerator{
    /**
     * Generates a connected dense graph defined as follows : N = `nodeCount` , E = N(N-1)/2 * 0.25 (quarter the number of edges of a complete graph).
     * @param nodeCount number of nodes
     * @return a Graph of Integers with N nodes and E edges
     */
    @Override
    public Graph<Integer> generate(int nodeCount) {
        Graph<Integer> graph = new Graph<>();
        Random random = new Random(42);
        Set<Edge<Integer>> addedEdges = new HashSet<>();

        for(int i = 0; i < nodeCount; i++){
            graph.addEdge(i, (i + 1)%nodeCount, random.nextInt(1000)); // make sure graph is connected
        }

        int remainingEdges = (nodeCount *(nodeCount - 1) /(2 * 4))  - nodeCount;
        // 1/4 * number of edges in a complete graph

        for (int i = 0; i < remainingEdges; i++){
            int from = random.nextInt(nodeCount);
            int to = random.nextInt(nodeCount);
            int weight = random.nextInt(1000);
            int tries = 0;
            while (addedEdges.contains(new Edge<>(from, to, weight))){
                // internally the hashCode relies on the `from`, `to` not the memory address so as the `equals` method.
                from = random.nextInt(nodeCount);
                to = random.nextInt(nodeCount);
                tries++;
                if (tries > nodeCount * nodeCount) // prevent infinite loops
                    return graph;
            }
            graph.addEdge(from, to, weight);
            addedEdges.add(new Edge<>(from, to, weight));
        }
        return graph;
    }
}
